﻿namespace TaskManagement_Adarsh
{
    public class ApiHelper
    {
        string url = "https://localhost:7080/Task/Login";
    }
}
