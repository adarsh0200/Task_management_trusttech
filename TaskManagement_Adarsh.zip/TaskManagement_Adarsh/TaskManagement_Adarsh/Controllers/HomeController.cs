﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using TaskManagement_Adarsh.Models;

namespace TaskManagement_Adarsh.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult Login()
        {
            return View();
        }
        public IActionResult Register()
        {
            return View();
        }
        public IActionResult HomePage(string user)
        {
            ViewBag.user = user;
            return View();
        }
        public IActionResult Createtask()
        {
            return View();
        }
        public IActionResult Tasks()
        {
            return View();
        }
        public IActionResult taskDetails(int task_Id)
        {
            ViewBag.taskId = task_Id;
            return View();
        }
        public IActionResult UpdateTask(int task_Id)
        {
            ViewBag.taskId = task_Id;
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}