﻿using Microsoft.AspNetCore.Mvc;
using TaskManagementAPI.Props;
using System.Text.Json;
using System.Text;

namespace TaskManagement_Adarsh.Controllers
{
    public class FunctionController : Controller
    {
        public async Task<IActionResult> loginCheck([FromBody]UserProps prop)
        {
            HttpClient client = new HttpClient();
            var inp = new StringContent(JsonSerializer.Serialize(prop), Encoding.UTF8, "application/json");
            var response = await client.PostAsync("https://localhost:7080/Task/Login", inp);
            
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return Ok(content);
            }
            else
            {
                return BadRequest("Invalid credentials!!");
            }
            
        }
        public async Task<IActionResult> Register([FromBody]UserProps prop)
        {
            HttpClient client = new HttpClient();
            var inp = new StringContent(JsonSerializer.Serialize(prop), Encoding.UTF8, "application/json");
            var response = await client.PostAsync("https://localhost:7080/Task/register", inp);

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return Ok(content);
            }
            else
            {
                return BadRequest("Unexpected error occured!!");
            }
        }
        public async Task<IActionResult> CreateTask([FromBody] TaskProp prop)
        {
            HttpClient client = new HttpClient();
            var inp = new StringContent(JsonSerializer.Serialize(prop), Encoding.UTF8, "application/json");
            var response = await client.PostAsync("https://localhost:7080/Task/CreateTask", inp);

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return Ok(content);
            }
            else
            {
                return BadRequest("Unexpected error occured!!");
            }
        }
        public async Task<IActionResult> UpdateTask([FromBody] TaskProp prop)
        {
            HttpClient client = new HttpClient();
            var inp = new StringContent(JsonSerializer.Serialize(prop), Encoding.UTF8, "application/json");
            var response = await client.PostAsync("https://localhost:7080/Task/UpdateTask", inp);

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return Ok(content);
            }
            else
            {
                return BadRequest("Unexpected error occured!!");
            }
        }

        public async Task<IActionResult> FetchTask(string status, DateTime dueDate, string user)
        {
            HttpClient client = new HttpClient();
            var response = await client.GetAsync("https://localhost:7080/Task/FetchTask?status=" + status+"&dueDate="+dueDate+"&user="+user);

            if (response.IsSuccessStatusCode)
            {
                var resp = await response.Content.ReadAsStringAsync();
                var content = JsonSerializer.Deserialize<List<TaskProp>>(resp);
                return Ok(content);
            }
            else
            {
                return BadRequest("Unexpected error occured!!");
            }
        }
        public async Task<IActionResult> FetchTaskDetails(int taskId)
        {
            HttpClient client = new HttpClient();
            var response = await client.GetAsync("https://localhost:7080/Task/FetchTaskDetails?taskId=" + taskId);

            if (response.IsSuccessStatusCode)
            {
                var resp = await response.Content.ReadAsStringAsync();
                var content = JsonSerializer.Deserialize<List<TaskProp>>(resp);
                return Ok(content);
            }
            else
            {
                return BadRequest("Unexpected error occured!!");
            }
        }
    }
}
