﻿namespace TaskManagementAPI.Props
{
    public class TaskProp
    {
        public string task_title { get; set; }
        public string description { get; set; }
        public DateTime due_date { get; set; }
        public decimal percentage { get; set; }
        public DateTime updated_date { get; set; }
        public DateTime created_date { get; set; }
        public int uId { get; set; }
        public string username { get; set; }
        public int task_id { get; set; }
        public string remark { get; set; }
        public string status { get; set; }
    }
}
