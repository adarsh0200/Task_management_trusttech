﻿using System.Data;
using System.Data.SqlClient;
using System.Xml.Linq;
using TaskManagementAPI.Props;

namespace TaskManagementAPI.DAL
{
    public class DbHelper
    {
        string constr = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\100687\\Documents\\TaskDb.mdf;Integrated Security=True;Connect Timeout=30";
        SqlConnection con = new SqlConnection();
        public void dal()
        {
            con.ConnectionString = constr;
            con.Open();
        }
        public dynamic executeQry(string query)
        {
            con.ConnectionString = constr;
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = query;
            if (query.ToLower().StartsWith("select"))
            {
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                con.Close();
                return ds.Tables[0];
            }
            else
            {
                cmd.ExecuteNonQuery();
                con.Close();
                return 1;
            }
        }
        public dynamic createTask(TaskProp obj)
        {
            con.ConnectionString = constr;
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "sp_createTask";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@title", SqlDbType.VarChar).Value = obj.task_title;
            cmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = obj.description;
            cmd.Parameters.Add("@dueDate", SqlDbType.Date).Value = obj.due_date;
            cmd.Parameters.Add("@user", SqlDbType.VarChar).Value = obj.username;
            SqlParameter par = cmd.Parameters.Add("@task_Id", SqlDbType.VarChar,25);
            par.Direction = ParameterDirection.Output;
            cmd.ExecuteNonQuery();
            con.Close();
            return par.Value;
        }
        public dynamic updateTask(TaskProp obj)
        {
            con.ConnectionString = constr;
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "sp_updateTask";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@task_id", SqlDbType.Int).Value = obj.task_id;
            cmd.Parameters.Add("@title", SqlDbType.VarChar).Value = obj.task_title;
            cmd.Parameters.Add("@Description", SqlDbType.VarChar).Value = obj.description;
            cmd.Parameters.Add("@dueDate", SqlDbType.Date).Value = obj.due_date;
            cmd.Parameters.Add("@percentage", SqlDbType.Decimal).Value = obj.percentage;
            cmd.Parameters.Add("@remark", SqlDbType.VarChar).Value = obj.remark;
            SqlParameter par = cmd.Parameters.Add("@status", SqlDbType.Int);
            par.Direction = ParameterDirection.Output;
            cmd.ExecuteNonQuery();
            con.Close();
            return par.Value;
        }
        public dynamic login(string username,string password)
        {
            con.ConnectionString = constr;
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "sp_login";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@username", SqlDbType.VarChar).Value = username;
            cmd.Parameters.Add("@password", SqlDbType.VarChar).Value = password;
            SqlParameter par = cmd.Parameters.Add("@status", SqlDbType.Int);
            par.Direction = ParameterDirection.Output;
            SqlParameter par1 = cmd.Parameters.Add("@session", SqlDbType.VarChar,250);
            par1.Direction = ParameterDirection.Output;
            cmd.ExecuteNonQuery();
            con.Close();
            return par.Value.ToString()+"^"+par1.Value;
        }
        public dynamic Register(string username, string password,string name)
        {
            con.ConnectionString = constr;
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = con;
            cmd.CommandText = "Sp_registerUser";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.Add("@username", SqlDbType.VarChar).Value = username;
            cmd.Parameters.Add("@name", SqlDbType.VarChar).Value = name;
            cmd.Parameters.Add("@password", SqlDbType.VarChar).Value = password;
            SqlParameter par = cmd.Parameters.Add("@status", SqlDbType.Int);
            par.Direction = ParameterDirection.Output;
            cmd.ExecuteNonQuery();
            con.Close();
            return par.Value;
        }
        public List<TaskProp> fetchTask(string status, DateTime dueDate, string user)
        {
            List<TaskProp> lst = new List<TaskProp>();
            string qry = "select t.task_id,t.task_title,t.due_date from task_master t where t.UId=(select b.UId from User_master b where b.Username='" + user + "')";
            
            if(dueDate == new DateTime(2000, 9, 1).Date)
            {
                if (status != "0")
                {
                    qry = "select t.task_id,t.task_title,t.due_date from task_master t where t.UId=(select b.UId from User_master b where b.Username='" + user + "') and t.status=" + status;
                }
            }
            else
            {
                if (status != "0")
                {
                    qry = "select t.task_id,t.task_title,t.due_date from task_master t where t.UId=(select b.UId from User_master b where b.Username='" + user + "') and t.status=" + status + "and t.due_date<='" + dueDate + "'";
                }
                else
                {
                    qry = "select t.task_id,t.task_title,t.due_date from task_master t where t.UId=(select b.UId from User_master b where b.Username='" + user + "') and t.due_date<='" + dueDate + "'";
                }
            }
            DataTable dt = executeQry(qry);
            for(int i=0; i<dt.Rows.Count; i++)
            {
                lst.Add(new TaskProp
                {
                    task_id = Convert.ToInt32(dt.Rows[i][0]),
                    task_title = Convert.ToString(dt.Rows[i][1]),
                    due_date = Convert.ToDateTime(dt.Rows[i][2])
                });
            }
            return lst;
        }
        public List<TaskProp> fetchTaskDetails(int taskId)
        {
            List<TaskProp> lst = new List<TaskProp>();
            DataTable dt = executeQry("select t.task_id,t.task_title,t.description,t.due_date,case t.status when 1 then 'INCOMPLETE' else 'COMPLETED' end as status,t.percentage,t.created_date from task_master t where t.Task_id=" + taskId);
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                lst.Add(new TaskProp
                {
                    task_id = Convert.ToInt32(dt.Rows[i][0]),
                    task_title = dt.Rows[i][1].ToString(),
                    description= dt.Rows[i][2].ToString(),
                    due_date = Convert.ToDateTime(dt.Rows[i][3]),
                    status = dt.Rows[i][4].ToString(),
                    percentage = Convert.ToDecimal(dt.Rows[i][5]),
                    created_date = Convert.ToDateTime(dt.Rows[i][6])
                });
            }
            return lst;
        }
    }
}
