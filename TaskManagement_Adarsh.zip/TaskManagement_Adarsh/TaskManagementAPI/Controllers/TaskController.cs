﻿using Microsoft.AspNetCore.Mvc;
using TaskManagementAPI.DAL;
using TaskManagementAPI.Props;

namespace TaskManagementAPI.Controllers
{
    [ApiController]
    [Route("Task")]
    public class TaskController : Controller
    {
        [HttpPost("Login")]
        public IActionResult Login([FromBody] UserProps prop)
        {
            DbHelper dbobj=new DbHelper();
            string a = dbobj.login(prop.UserName,prop.Password);
            string[] ar=a.Split('^');
            if (ar[0] == "1")
            {
                return Ok("sucessfully logged in^" + ar[1]);
            }
            else
            {
                return BadRequest("Invalid credentials");
            }
        }
        [HttpPost("Register")]
        public IActionResult register([FromBody] UserProps prop)
        {
            var dbobj = new DbHelper();
            string result=dbobj.Register(prop.UserName,prop.Password,prop.Name).ToString();
            if (result == "1")
            {
                return Ok("Sucessfully Registered^" + result);
            }
            else if (result == "0")
            {
                return Ok("Username already exist Try another");
            }
            else
            {
                return BadRequest("Unexpected error occured");
            }
        }
        [HttpPost("CreateTask")]
        public IActionResult CreateTask([FromBody]TaskProp task)
        {
            var dbobj=new DbHelper();
            int result=Convert.ToInt32(dbobj.createTask(task));
            if (result > 0) 
            {
                return Ok("Task created successfully Task Id:" + result.ToString());
            }
            else
            {
                return BadRequest("Unexpected error occured");
            }
        }
        [HttpPost("UpdateTask")]
        public IActionResult UpdateTask([FromBody]TaskProp task)
        {
            var dbobj=new DbHelper();
            int result= Convert.ToInt32(dbobj.updateTask(task));
            if (result == 1)
            {
                return Ok("Task Updated Successfully");
            }
            else if(result == 2)
            {
                return Ok("Task completed successfully");
            }
            else if(result == 3)
            {
                return Ok("Task Deleted Successfully");
            }
            else
            {
                return BadRequest("Unexpected error occured");
            }
        }
        [HttpGet("FetchTask")]
        public IActionResult FetchTasks(string status,DateTime dueDate,string user)
        {
            List<TaskProp> lst = new List<TaskProp>();
            DbHelper dbobj = new DbHelper();
            lst = dbobj.fetchTask(status,dueDate, user);
            return Ok(lst);
        }
        [HttpGet("FetchTaskDetails")]
        public IActionResult FetchTasksDetails( int taskId)
        {
            List<TaskProp> lst = new List<TaskProp>();
            DbHelper dbobj = new DbHelper();
            lst = dbobj.fetchTaskDetails(taskId);
            return Ok(lst);
        }
    }
}
